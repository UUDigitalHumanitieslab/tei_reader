#!/usr/bin/env python3
from .element import Element

class Part(Element):
    is_placeholder = False
